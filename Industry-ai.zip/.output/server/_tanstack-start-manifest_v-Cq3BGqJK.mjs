//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Cq3BGqJK.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "D:/industry-ai-os (1)/src/routes/__root.tsx",
		children: ["/", "/app"],
		preloads: [
			"/assets/index-Coii76eM.js",
			"/assets/jsx-runtime-bzQ4Vb5N.js",
			"/assets/Match-mksSHDTZ.js",
			"/assets/useNavigate-Dp7Leol8.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Coii76eM.js"
		} }]
	},
	"/": {
		filePath: "D:/industry-ai-os (1)/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-CIsC1obn.js",
			"/assets/createLucideIcon-DeQrcgrh.js",
			"/assets/theme-C80WsXdl.js",
			"/assets/api-BMElqTY2.js",
			"/assets/IntegrationLogo-BzsdTxOY.js",
			"/assets/utils-BtRqtsxU.js"
		]
	},
	"/app": {
		filePath: "D:/industry-ai-os (1)/src/routes/app.tsx",
		children: [
			"/app/admin",
			"/app/analytics",
			"/app/approvals",
			"/app/assistant",
			"/app/connectors",
			"/app/documents",
			"/app/knowledge",
			"/app/settings",
			"/app/workflows",
			"/app/"
		],
		preloads: [
			"/assets/app-CBLz7-u6.js",
			"/assets/session-CZtZZhEh.js",
			"/assets/createLucideIcon-DeQrcgrh.js",
			"/assets/book-open-N3QWHV8E.js",
			"/assets/bot-ChBJeZ8N.js",
			"/assets/cable-Bi_RhUOf.js",
			"/assets/chart-column-DZv2trJs.js",
			"/assets/search-DUtlf6EF.js",
			"/assets/clipboard-check-rDC8UPIg.js",
			"/assets/file-text-ZyrQALT9.js",
			"/assets/states-Bp4d1CUc.js",
			"/assets/theme-C80WsXdl.js",
			"/assets/settings-Bm47K_c5.js",
			"/assets/shield-check-DRzoqlHD.js",
			"/assets/workflow-DPP1PLDw.js",
			"/assets/api-BMElqTY2.js",
			"/assets/utils-BtRqtsxU.js"
		]
	},
	"/app/admin": {
		filePath: "D:/industry-ai-os (1)/src/routes/app.admin.tsx",
		children: void 0,
		preloads: ["/assets/app.admin-DNhE_0CX.js", "/assets/PageHeader-DBmwpyqv.js"]
	},
	"/app/analytics": {
		filePath: "D:/industry-ai-os (1)/src/routes/app.analytics.tsx",
		children: void 0,
		preloads: ["/assets/app.analytics-13jckzdP.js", "/assets/PageHeader-DBmwpyqv.js"]
	},
	"/app/approvals": {
		filePath: "D:/industry-ai-os (1)/src/routes/app.approvals.tsx",
		children: void 0,
		preloads: ["/assets/app.approvals-DGQaT06e.js", "/assets/PageHeader-DBmwpyqv.js"]
	},
	"/app/assistant": {
		filePath: "D:/industry-ai-os (1)/src/routes/app.assistant.tsx",
		children: void 0,
		preloads: ["/assets/app.assistant-D3fBcMe0.js", "/assets/PageHeader-DBmwpyqv.js"]
	},
	"/app/connectors": {
		filePath: "D:/industry-ai-os (1)/src/routes/app.connectors.tsx",
		children: void 0,
		preloads: [
			"/assets/app.connectors-Cz-KTrdQ.js",
			"/assets/PageHeader-DBmwpyqv.js",
			"/assets/IntegrationLogo-BzsdTxOY.js"
		]
	},
	"/app/documents": {
		filePath: "D:/industry-ai-os (1)/src/routes/app.documents.tsx",
		children: void 0,
		preloads: ["/assets/app.documents-DkI4Uflc.js", "/assets/PageHeader-DBmwpyqv.js"]
	},
	"/app/knowledge": {
		filePath: "D:/industry-ai-os (1)/src/routes/app.knowledge.tsx",
		children: void 0,
		preloads: ["/assets/app.knowledge-Zj5Kzudj.js", "/assets/PageHeader-DBmwpyqv.js"]
	},
	"/app/settings": {
		filePath: "D:/industry-ai-os (1)/src/routes/app.settings.tsx",
		children: void 0,
		preloads: ["/assets/app.settings-DXm59Lxf.js", "/assets/PageHeader-DBmwpyqv.js"]
	},
	"/app/workflows": {
		filePath: "D:/industry-ai-os (1)/src/routes/app.workflows.tsx",
		children: void 0,
		preloads: ["/assets/app.workflows-5-1IUjl-.js", "/assets/PageHeader-DBmwpyqv.js"]
	},
	"/app/": {
		filePath: "D:/industry-ai-os (1)/src/routes/app.index.tsx",
		children: void 0,
		preloads: ["/assets/app.index-CTV92CpG.js", "/assets/PageHeader-DBmwpyqv.js"]
	}
} });
//#endregion
export { tsrStartManifest };

globalThis.__nitro_main__ = import.meta.url;
import { a as FastResponse, n as HTTPError, r as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"4f95-3RXc3p2mhEAs1WBwaIvE0Y0uu0Y\"",
		"mtime": "2026-07-09T05:34:46.181Z",
		"size": 20373,
		"path": "../public/favicon.ico"
	},
	"/assets/api-BMElqTY2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d31-4TXQNWaRGMLJzKSFDrMfIK1fs+s\"",
		"mtime": "2026-07-09T07:04:13.398Z",
		"size": 3377,
		"path": "../public/assets/api-BMElqTY2.js"
	},
	"/assets/app-CBLz7-u6.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"15fba-VtKeuuJkCULPunywYKSt9JVZ0sM\"",
		"mtime": "2026-07-09T07:04:13.399Z",
		"size": 90042,
		"path": "../public/assets/app-CBLz7-u6.js"
	},
	"/assets/app.admin-DNhE_0CX.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"33a-64/2joBA6z6wQa40odIgF/6gtWE\"",
		"mtime": "2026-07-09T07:04:13.399Z",
		"size": 826,
		"path": "../public/assets/app.admin-DNhE_0CX.js"
	},
	"/assets/app.analytics-13jckzdP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"29e-lKbV+s9G/bZXiT/Nged/HeaxERU\"",
		"mtime": "2026-07-09T07:04:13.400Z",
		"size": 670,
		"path": "../public/assets/app.analytics-13jckzdP.js"
	},
	"/assets/app.approvals-DGQaT06e.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"23e-bw/VVaDyT1vPxsWnU5ddz9poSD0\"",
		"mtime": "2026-07-09T07:04:13.400Z",
		"size": 574,
		"path": "../public/assets/app.approvals-DGQaT06e.js"
	},
	"/assets/app.assistant-D3fBcMe0.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"21b-uTt8pLdF6O2VTlsqP2TDAZi2MDY\"",
		"mtime": "2026-07-09T07:04:13.401Z",
		"size": 539,
		"path": "../public/assets/app.assistant-D3fBcMe0.js"
	},
	"/assets/app.connectors-Cz-KTrdQ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"dca-X4YOTPCA5Vri36tm+6j1TiqAcRo\"",
		"mtime": "2026-07-09T07:04:13.402Z",
		"size": 3530,
		"path": "../public/assets/app.connectors-Cz-KTrdQ.js"
	},
	"/assets/app.documents-DkI4Uflc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"215-unmwafJiMeAqUAtWqnzsOQns4b0\"",
		"mtime": "2026-07-09T07:04:13.402Z",
		"size": 533,
		"path": "../public/assets/app.documents-DkI4Uflc.js"
	},
	"/assets/app.index-CTV92CpG.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1eab-5aPRQTX0IGUbdhzJdWTbTRWf8gM\"",
		"mtime": "2026-07-09T07:04:13.403Z",
		"size": 7851,
		"path": "../public/assets/app.index-CTV92CpG.js"
	},
	"/assets/app.knowledge-Zj5Kzudj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"22c-PuN2jZjw2bJdkmOQBlWe0i1XoSs\"",
		"mtime": "2026-07-09T07:04:13.403Z",
		"size": 556,
		"path": "../public/assets/app.knowledge-Zj5Kzudj.js"
	},
	"/assets/app.settings-DXm59Lxf.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"262-A9fYzn2WxOqvdcCDIqRQURLrFwo\"",
		"mtime": "2026-07-09T07:04:13.404Z",
		"size": 610,
		"path": "../public/assets/app.settings-DXm59Lxf.js"
	},
	"/assets/app.workflows-5-1IUjl-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"216-Na9RMWr7tI7nxTrIthg5p/XOOps\"",
		"mtime": "2026-07-09T07:04:13.405Z",
		"size": 534,
		"path": "../public/assets/app.workflows-5-1IUjl-.js"
	},
	"/assets/book-open-N3QWHV8E.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"117-DnvXe7JKM3EjPvaGrzmctoaKzyY\"",
		"mtime": "2026-07-09T07:04:13.405Z",
		"size": 279,
		"path": "../public/assets/book-open-N3QWHV8E.js"
	},
	"/assets/bot-ChBJeZ8N.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"148-wCd0VK71QeJ/Qw+n+J/8KjJ1Ks8\"",
		"mtime": "2026-07-09T07:04:13.405Z",
		"size": 328,
		"path": "../public/assets/bot-ChBJeZ8N.js"
	},
	"/assets/cable-Bi_RhUOf.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ee-PaM299KPJVfeuqjjQKGGNngSgnA\"",
		"mtime": "2026-07-09T07:04:13.407Z",
		"size": 494,
		"path": "../public/assets/cable-Bi_RhUOf.js"
	},
	"/assets/chart-column-DZv2trJs.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"fb-JT+Q/JRX5vDIPHXAdKIVA4x9nps\"",
		"mtime": "2026-07-09T07:04:13.407Z",
		"size": 251,
		"path": "../public/assets/chart-column-DZv2trJs.js"
	},
	"/assets/createLucideIcon-DeQrcgrh.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4ab-cR1PODv03KUfJz4HloEEypYngbs\"",
		"mtime": "2026-07-09T07:04:13.408Z",
		"size": 1195,
		"path": "../public/assets/createLucideIcon-DeQrcgrh.js"
	},
	"/assets/clipboard-check-rDC8UPIg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"130-aep9aiDHT4YfsQhi5oaNUXRmnrk\"",
		"mtime": "2026-07-09T07:04:13.408Z",
		"size": 304,
		"path": "../public/assets/clipboard-check-rDC8UPIg.js"
	},
	"/assets/file-text-ZyrQALT9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"181-kTLQI5MCNTntekNWsJv0H7U9GI8\"",
		"mtime": "2026-07-09T07:04:13.409Z",
		"size": 385,
		"path": "../public/assets/file-text-ZyrQALT9.js"
	},
	"/assets/IntegrationLogo-BzsdTxOY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c89-n+iXOyDTf57RJLKofFIbikREnMA\"",
		"mtime": "2026-07-09T07:04:13.395Z",
		"size": 3209,
		"path": "../public/assets/IntegrationLogo-BzsdTxOY.js"
	},
	"/assets/index-Coii76eM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"409eb-Tq0Pah4Qey1w67eFu4Zy0RjKtSs\"",
		"mtime": "2026-07-09T07:04:13.395Z",
		"size": 264683,
		"path": "../public/assets/index-Coii76eM.js"
	},
	"/assets/jsx-runtime-bzQ4Vb5N.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"20d8-vMfP+4a4ykIjbw4InHkj3E5HWt0\"",
		"mtime": "2026-07-09T07:04:13.409Z",
		"size": 8408,
		"path": "../public/assets/jsx-runtime-bzQ4Vb5N.js"
	},
	"/assets/Match-mksSHDTZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"127e9-S6unyv1MtRu3WZMjKh7XauLQCAE\"",
		"mtime": "2026-07-09T07:04:13.396Z",
		"size": 75753,
		"path": "../public/assets/Match-mksSHDTZ.js"
	},
	"/assets/PageHeader-DBmwpyqv.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"206-nvVGoewLfGjpfqIBOj4VdYsgMnw\"",
		"mtime": "2026-07-09T07:04:13.397Z",
		"size": 518,
		"path": "../public/assets/PageHeader-DBmwpyqv.js"
	},
	"/assets/routes-CIsC1obn.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7eca-+PWUHrXFyteYNNr1hRsPqdz37yc\"",
		"mtime": "2026-07-09T07:04:13.409Z",
		"size": 32458,
		"path": "../public/assets/routes-CIsC1obn.js"
	},
	"/assets/search-DUtlf6EF.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f5-1aZhsjZbs+p3fL4Pf2ypv5gM0ok\"",
		"mtime": "2026-07-09T07:04:13.411Z",
		"size": 245,
		"path": "../public/assets/search-DUtlf6EF.js"
	},
	"/assets/session-CZtZZhEh.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2471-Rn/zSSoeqWpGA7Bydj8pA5dwgVk\"",
		"mtime": "2026-07-09T07:04:13.411Z",
		"size": 9329,
		"path": "../public/assets/session-CZtZZhEh.js"
	},
	"/assets/settings-Bm47K_c5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1e7-gJ3oXHGycBL5js6pOZ8/aeoTK6Y\"",
		"mtime": "2026-07-09T07:04:13.411Z",
		"size": 487,
		"path": "../public/assets/settings-Bm47K_c5.js"
	},
	"/assets/shield-check-DRzoqlHD.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"140-iO/tYQHTO9QhR8R/dBMGVcYHM3w\"",
		"mtime": "2026-07-09T07:04:13.412Z",
		"size": 320,
		"path": "../public/assets/shield-check-DRzoqlHD.js"
	},
	"/assets/states-Bp4d1CUc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6e3-YeFy5ZDkibFaDUOhLfOU8ACGJjI\"",
		"mtime": "2026-07-09T07:04:13.412Z",
		"size": 1763,
		"path": "../public/assets/states-Bp4d1CUc.js"
	},
	"/assets/styles-Bfqyp-D-.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"14a59-2kU0W2m0t+PbXcimwu4n0JscM+M\"",
		"mtime": "2026-07-09T07:04:13.417Z",
		"size": 84569,
		"path": "../public/assets/styles-Bfqyp-D-.css"
	},
	"/assets/theme-C80WsXdl.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"56f-g6JZN8bkPwnfI8Egu8p5Km3aMcw\"",
		"mtime": "2026-07-09T07:04:13.412Z",
		"size": 1391,
		"path": "../public/assets/theme-C80WsXdl.js"
	},
	"/assets/useNavigate-Dp7Leol8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"fe-ZTUEPWDfxsTBrXmr7Zqtg8+jHKU\"",
		"mtime": "2026-07-09T07:04:13.414Z",
		"size": 254,
		"path": "../public/assets/useNavigate-Dp7Leol8.js"
	},
	"/assets/utils-BtRqtsxU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6a76-JkKQpQvQjju9Gum3ePYtjWZ23Rg\"",
		"mtime": "2026-07-09T07:04:13.415Z",
		"size": 27254,
		"path": "../public/assets/utils-BtRqtsxU.js"
	},
	"/assets/workflow-DPP1PLDw.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"109-TteN8mILxJlDLm9t5NSK5OVHk38\"",
		"mtime": "2026-07-09T07:04:13.416Z",
		"size": 265,
		"path": "../public/assets/workflow-DPP1PLDw.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_sKPzj6 = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_sKPzj6
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };

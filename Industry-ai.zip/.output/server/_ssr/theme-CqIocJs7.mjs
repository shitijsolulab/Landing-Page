import { n as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/theme-CqIocJs7.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var THEME_KEY = "aios.theme";
var Ctx = (0, import_react.createContext)(null);
function ThemeProvider({ children }) {
	const [theme, setThemeState] = (0, import_react.useState)("light");
	(0, import_react.useEffect)(() => {
		const stored = window.localStorage.getItem(THEME_KEY);
		if (stored === "light" || stored === "dark") setThemeState(stored);
		else if (window.matchMedia?.("(prefers-color-scheme: dark)").matches) setThemeState("dark");
	}, []);
	const setTheme = (0, import_react.useCallback)((t) => {
		setThemeState(t);
		window.localStorage.setItem(THEME_KEY, t);
	}, []);
	const toggle = (0, import_react.useCallback)(() => {
		setThemeState((prev) => {
			const next = prev === "dark" ? "light" : "dark";
			window.localStorage.setItem(THEME_KEY, next);
			return next;
		});
	}, []);
	const value = (0, import_react.useMemo)(() => ({
		theme,
		setTheme,
		toggle
	}), [
		theme,
		setTheme,
		toggle
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ctx.Provider, {
		value,
		children
	});
}
function useTheme() {
	const ctx = (0, import_react.useContext)(Ctx);
	if (!ctx) throw new Error("useTheme must be used within ThemeProvider");
	return ctx;
}
//#endregion
export { useTheme as n, ThemeProvider as t };

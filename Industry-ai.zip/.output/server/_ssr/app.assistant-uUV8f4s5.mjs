import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { T as Bot } from "../_libs/lucide-react.mjs";
import { t as EmptyState } from "./states-DyvfUIqi.mjs";
import { t as PageHeader } from "./PageHeader-B81R5vrl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/app.assistant-uUV8f4s5.js
var import_jsx_runtime = require_jsx_runtime();
function Assistant() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		title: "AI Assistant",
		description: "Chat grounded in your organization's data."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
		icon: Bot,
		title: "Assistant is being built",
		description: "Streaming chat, document upload, citations, and history — wired to the orchestrator service — arrive in the next build step."
	})] });
}
//#endregion
export { Assistant as component };

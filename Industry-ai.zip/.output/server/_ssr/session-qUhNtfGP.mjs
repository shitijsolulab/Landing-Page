import { n as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as api } from "./api-BBLZWzDa.mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/session-qUhNtfGP.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Ctx = (0, import_react.createContext)(null);
function SessionProvider({ children, onUnauthenticated }) {
	const { data, isLoading, error } = useQuery({
		queryKey: ["me"],
		queryFn: api.getMe,
		retry: false,
		staleTime: 300 * 1e3
	});
	if (error && onUnauthenticated) onUnauthenticated();
	const me = data ?? null;
	const roles = me?.roles ?? [];
	const hasRole = (...want) => want.some((r) => roles.includes(r));
	const isManager = hasRole("owner", "admin");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ctx.Provider, {
		value: {
			me,
			isLoading,
			error,
			hasRole,
			isManager
		},
		children
	});
}
function useSession() {
	const ctx = (0, import_react.useContext)(Ctx);
	if (!ctx) throw new Error("useSession must be used within SessionProvider");
	return ctx;
}
//#endregion
export { useSession as n, SessionProvider as t };

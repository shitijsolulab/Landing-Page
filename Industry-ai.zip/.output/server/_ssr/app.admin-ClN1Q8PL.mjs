import { n as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as ShieldCheck } from "../_libs/lucide-react.mjs";
import { t as EmptyState } from "./states-DyvfUIqi.mjs";
import { n as useSession } from "./session-qUhNtfGP.mjs";
import { g as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as PageHeader } from "./PageHeader-B81R5vrl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/app.admin-ClN1Q8PL.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Admin() {
	const { isManager, isLoading } = useSession();
	const navigate = useNavigate();
	(0, import_react.useEffect)(() => {
		if (!isLoading && !isManager) navigate({ to: "/app" });
	}, [
		isLoading,
		isManager,
		navigate
	]);
	if (!isManager) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		title: "Admin",
		description: "RBAC, users, roles, connectors, prompts, and audit logs."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
		icon: ShieldCheck,
		title: "Admin console is being built",
		description: "Organizations, users, roles, connector management, and audit logs — wired to identity + admin + audit services — arrive next. (Prompt management needs a new backend endpoint.)"
	})] });
}
//#endregion
export { Admin as component };

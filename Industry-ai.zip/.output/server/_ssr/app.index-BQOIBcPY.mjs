import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { C as Cable, d as MessagesSquare, g as FileText, k as Activity, n as Workflow, v as ClipboardCheck } from "../_libs/lucide-react.mjs";
import { n as ErrorState, r as LoadingState, t as EmptyState } from "./states-DyvfUIqi.mjs";
import { n as api } from "./api-BBLZWzDa.mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { n as useSession } from "./session-qUhNtfGP.mjs";
import { t as PageHeader } from "./PageHeader-B81R5vrl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/app.index-BQOIBcPY.js
var import_jsx_runtime = require_jsx_runtime();
function DataTable({ columns, rows, rowKey, isLoading, error, onRetry, onRowClick, emptyIcon, emptyTitle = "Nothing here yet", emptyDescription }) {
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingState, {});
	if (error) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorState, {
		message: error instanceof Error ? error.message : "Failed to load.",
		onRetry
	});
	if (!rows || rows.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
		icon: emptyIcon,
		title: emptyTitle,
		description: emptyDescription
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "overflow-x-auto rounded-lg border border-border",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
			className: "w-full min-w-[640px] text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
				className: "border-b border-border bg-surface-2/60",
				children: columns.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
					className: `px-4 py-2.5 text-xs font-medium uppercase tracking-wide text-muted-foreground ${c.align === "right" ? "text-right" : "text-left"}`,
					children: c.header
				}, c.key))
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
				onClick: onRowClick ? () => onRowClick(row) : void 0,
				className: `border-b border-border/60 last:border-0 ${onRowClick ? "cursor-pointer hover:bg-surface-2/50" : ""}`,
				children: columns.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: `px-4 py-3 text-foreground/90 ${c.align === "right" ? "text-right" : "text-left"} ${c.className ?? ""}`,
					children: c.render ? c.render(row) : row[c.key]
				}, c.key))
			}, rowKey(row))) })]
		})
	});
}
function StatCard({ label, value, hint, icon: Icon, loading, tone = "default" }) {
	const toneClass = {
		default: "text-foreground",
		warning: "text-amber-500",
		danger: "text-destructive",
		success: "text-emerald-500"
	}[tone];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg border border-border bg-card p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs font-medium uppercase tracking-wide text-muted-foreground",
					children: label
				}), Icon && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4 text-muted-foreground" })]
			}),
			loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-3 h-7 w-16 animate-pulse rounded bg-muted" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: `mt-2 text-2xl font-semibold tabular-nums ${toneClass}`,
				children: value
			}),
			hint && !loading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs text-muted-foreground",
				children: hint
			})
		]
	});
}
var TONE = {
	ok: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400",
	approved: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400",
	processed: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400",
	completed: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400",
	enabled: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400",
	running: "bg-amber-500/15 text-amber-600 dark:text-amber-400",
	processing: "bg-amber-500/15 text-amber-600 dark:text-amber-400",
	awaiting_approval: "bg-amber-500/15 text-amber-600 dark:text-amber-400",
	degraded: "bg-amber-500/15 text-amber-600 dark:text-amber-400",
	pending: "bg-amber-500/15 text-amber-600 dark:text-amber-400",
	rejected: "bg-destructive/15 text-destructive",
	failed: "bg-destructive/15 text-destructive",
	down: "bg-destructive/15 text-destructive",
	error: "bg-destructive/15 text-destructive"
};
function StatusBadge({ status }) {
	const tone = TONE[status?.toLowerCase()] ?? "bg-muted text-muted-foreground";
	const label = status?.replace(/_/g, " ") ?? "unknown";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium capitalize ${tone}`,
		children: label
	});
}
function Dashboard() {
	const { me, isManager } = useSession();
	const workflows = useQuery({
		queryKey: ["workflows"],
		queryFn: api.listWorkflows
	});
	const documents = useQuery({
		queryKey: ["documents"],
		queryFn: api.listDocuments
	});
	const connectors = useQuery({
		queryKey: ["connectors"],
		queryFn: api.listConnectors
	});
	const health = useQuery({
		queryKey: ["health"],
		queryFn: api.systemHealth
	});
	const audit = useQuery({
		queryKey: ["audit", "recent"],
		queryFn: () => api.listAuditEvents({ limit: 8 }),
		enabled: isManager
	});
	const wf = workflows.data ?? [];
	const activeCount = wf.filter((w) => w.status === "running").length;
	const pendingCount = wf.filter((w) => w.status === "awaiting_approval").length;
	const connectedCount = (connectors.data ?? []).filter((c) => c.enabled).length;
	const docCount = (documents.data ?? []).length;
	const healthTone = health.data?.overall === "ok" ? "success" : health.data ? "warning" : "default";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: `Welcome${me?.email ? `, ${me.email.split("@")[0]}` : ""}`,
			description: "Your organization's AI operations at a glance."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-2 gap-3 lg:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Active Workflows",
					value: activeCount,
					icon: Workflow,
					loading: workflows.isLoading
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Pending Approvals",
					value: pendingCount,
					icon: ClipboardCheck,
					loading: workflows.isLoading,
					tone: pendingCount > 0 ? "warning" : "default"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Connected Systems",
					value: connectedCount,
					icon: Cable,
					loading: connectors.isLoading
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Documents",
					value: docCount,
					icon: FileText,
					loading: documents.isLoading
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 grid grid-cols-2 gap-3 lg:grid-cols-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
				label: "System Health",
				value: health.data?.overall ? health.data.overall.toUpperCase() : "—",
				icon: Activity,
				loading: health.isLoading,
				tone: healthTone,
				hint: health.data ? `${Object.keys(health.data.services).length} services` : void 0
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
				label: "AI Conversations",
				value: "—",
				icon: MessagesSquare,
				hint: "History API coming soon"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 grid gap-6 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-3 text-sm font-semibold text-foreground",
				children: "Recent Documents"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
				columns: [
					{
						key: "filename",
						header: "Document",
						render: (d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium",
							children: d.filename
						})
					},
					{
						key: "status",
						header: "Status",
						render: (d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: d.status })
					},
					{
						key: "created_at",
						header: "Uploaded",
						align: "right",
						render: (d) => new Date(d.created_at).toLocaleDateString()
					}
				],
				rows: (documents.data ?? []).slice(0, 6),
				rowKey: (d) => d.id,
				isLoading: documents.isLoading,
				error: documents.error,
				onRetry: () => documents.refetch(),
				emptyIcon: FileText,
				emptyTitle: "No documents yet",
				emptyDescription: "Uploaded documents will appear here."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-3 text-sm font-semibold text-foreground",
				children: "Audit Activity"
			}), !isManager ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				icon: Activity,
				title: "Restricted",
				description: "Audit activity is visible to admins and owners."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuditList, {
				events: audit.data,
				loading: audit.isLoading
			})] })]
		}),
		health.data && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-3 text-sm font-semibold text-foreground",
				children: "Connected Services"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4",
				children: Object.entries(health.data.services).map(([name, status]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between rounded-lg border border-border bg-card px-3 py-2.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm capitalize",
						children: name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status })]
				}, name))
			})]
		})
	] });
}
function AuditList({ events, loading }) {
	if (loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-40 animate-pulse rounded-lg bg-muted" });
	if (!events || events.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
		icon: Activity,
		title: "No recent activity"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "divide-y divide-border rounded-lg border border-border",
		children: events.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "flex items-center justify-between gap-3 px-4 py-2.5 text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "truncate font-medium",
					children: e.action.replace(/\./g, " · ")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "truncate text-xs text-muted-foreground",
					children: [
						e.actor_email ?? e.actor_id,
						" · ",
						e.resource_kind
					]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "shrink-0 text-xs text-muted-foreground",
				children: new Date(e.created_at).toLocaleTimeString([], {
					hour: "2-digit",
					minute: "2-digit"
				})
			})]
		}, e.id))
	});
}
//#endregion
export { Dashboard as component };

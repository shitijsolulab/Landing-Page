import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { v as ClipboardCheck } from "../_libs/lucide-react.mjs";
import { t as EmptyState } from "./states-DyvfUIqi.mjs";
import { t as PageHeader } from "./PageHeader-B81R5vrl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/app.approvals-CLAQU2wX.js
var import_jsx_runtime = require_jsx_runtime();
function Approvals() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		title: "Approvals",
		description: "Review and act on items awaiting a human decision."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
		icon: ClipboardCheck,
		title: "Approval queue is being built",
		description: "Pending items, review screen, approve/reject with comments, and an audit timeline — wired to the workflow + audit services — arrive next."
	})] });
}
//#endregion
export { Approvals as component };

import { n as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/IntegrationLogo-DC2hzUur.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var CATEGORIES = [
	"Accounting",
	"Banking",
	"Construction",
	"HR & ATS",
	"Productivity"
];
var INTEGRATIONS = [
	{
		slug: "quickbooks",
		name: "QuickBooks",
		domain: "quickbooks.intuit.com",
		category: "Accounting"
	},
	{
		slug: "xero",
		name: "Xero",
		domain: "xero.com",
		category: "Accounting"
	},
	{
		slug: "netsuite",
		name: "NetSuite",
		domain: "netsuite.com",
		category: "Accounting"
	},
	{
		slug: "sage",
		name: "Sage",
		domain: "sage.com",
		category: "Accounting"
	},
	{
		slug: "freshbooks",
		name: "FreshBooks",
		domain: "freshbooks.com",
		category: "Accounting"
	},
	{
		slug: "bill",
		name: "BILL",
		domain: "bill.com",
		category: "Accounting"
	},
	{
		slug: "plaid",
		name: "Plaid",
		domain: "plaid.com",
		category: "Banking",
		auth: true
	},
	{
		slug: "stripe",
		name: "Stripe",
		domain: "stripe.com",
		category: "Banking"
	},
	{
		slug: "brex",
		name: "Brex",
		domain: "brex.com",
		category: "Banking"
	},
	{
		slug: "ramp",
		name: "Ramp",
		domain: "ramp.com",
		category: "Banking"
	},
	{
		slug: "mercury",
		name: "Mercury",
		domain: "mercury.com",
		category: "Banking"
	},
	{
		slug: "wise",
		name: "Wise",
		domain: "wise.com",
		category: "Banking"
	},
	{
		slug: "procore",
		name: "Procore",
		domain: "procore.com",
		category: "Construction"
	},
	{
		slug: "autodesk",
		name: "Autodesk Construction Cloud",
		domain: "autodesk.com",
		category: "Construction"
	},
	{
		slug: "buildertrend",
		name: "Buildertrend",
		domain: "buildertrend.com",
		category: "Construction"
	},
	{
		slug: "fieldwire",
		name: "Fieldwire",
		domain: "fieldwire.com",
		category: "Construction"
	},
	{
		slug: "bluebeam",
		name: "Bluebeam",
		domain: "bluebeam.com",
		category: "Construction"
	},
	{
		slug: "primavera",
		name: "Oracle Primavera P6",
		domain: "oracle.com",
		category: "Construction"
	},
	{
		slug: "workday",
		name: "Workday",
		domain: "workday.com",
		category: "HR & ATS"
	},
	{
		slug: "greenhouse",
		name: "Greenhouse",
		domain: "greenhouse.io",
		category: "HR & ATS"
	},
	{
		slug: "lever",
		name: "Lever",
		domain: "lever.co",
		category: "HR & ATS"
	},
	{
		slug: "bamboohr",
		name: "BambooHR",
		domain: "bamboohr.com",
		category: "HR & ATS"
	},
	{
		slug: "gusto",
		name: "Gusto",
		domain: "gusto.com",
		category: "HR & ATS"
	},
	{
		slug: "rippling",
		name: "Rippling",
		domain: "rippling.com",
		category: "HR & ATS"
	},
	{
		slug: "notion",
		name: "Notion",
		domain: "notion.so",
		category: "Productivity"
	},
	{
		slug: "confluence",
		name: "Confluence",
		domain: "atlassian.com",
		category: "Productivity"
	},
	{
		slug: "airtable",
		name: "Airtable",
		domain: "airtable.com",
		category: "Productivity"
	},
	{
		slug: "gsheets",
		name: "Google Sheets",
		domain: "sheets.google.com",
		category: "Productivity"
	},
	{
		slug: "gcalendar",
		name: "Google Calendar",
		domain: "calendar.google.com",
		category: "Productivity",
		auth: true
	},
	{
		slug: "gdrive",
		name: "Google Drive",
		domain: "drive.google.com",
		category: "Productivity",
		auth: true
	}
];
function logoUrl(domain) {
	return `https://logo.clearbit.com/${domain}`;
}
function initials(name) {
	return name.replace(/[^\w\s]/g, "").split(/\s+/).slice(0, 2).map((w) => w[0]?.toUpperCase() ?? "").join("");
}
function IntegrationLogo({ name, domain, className }) {
	const [failed, setFailed] = (0, import_react.useState)(false);
	if (!domain || failed) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("grid shrink-0 place-items-center rounded-lg bg-secondary text-[13px] font-semibold text-muted-foreground", className),
		children: initials(name)
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("grid shrink-0 place-items-center overflow-hidden rounded-lg bg-white ring-1 ring-black/5", className),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: logoUrl(domain),
			alt: "",
			loading: "lazy",
			onError: () => setFailed(true),
			className: "h-3/5 w-3/5 object-contain"
		})
	});
}
//#endregion
export { INTEGRATIONS as n, IntegrationLogo as r, CATEGORIES as t };

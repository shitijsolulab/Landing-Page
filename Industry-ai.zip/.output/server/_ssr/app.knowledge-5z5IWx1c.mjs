import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { E as BookOpen } from "../_libs/lucide-react.mjs";
import { t as EmptyState } from "./states-DyvfUIqi.mjs";
import { t as PageHeader } from "./PageHeader-B81R5vrl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/app.knowledge-5z5IWx1c.js
var import_jsx_runtime = require_jsx_runtime();
function Knowledge() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		title: "Knowledge",
		description: "Semantic search across your organization's documents."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
		icon: BookOpen,
		title: "Knowledge search is being built",
		description: "Semantic search with sources, confidence scores, and filters — wired to the knowledge retrieval endpoint — arrives next."
	})] });
}
//#endregion
export { Knowledge as component };

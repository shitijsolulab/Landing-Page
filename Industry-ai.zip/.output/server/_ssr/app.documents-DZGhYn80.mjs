import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { g as FileText } from "../_libs/lucide-react.mjs";
import { t as EmptyState } from "./states-DyvfUIqi.mjs";
import { t as PageHeader } from "./PageHeader-B81R5vrl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/app.documents-DZGhYn80.js
var import_jsx_runtime = require_jsx_runtime();
function Documents() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		title: "Documents",
		description: "Upload, search, and track document processing."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
		icon: FileText,
		title: "Document library is being built",
		description: "Upload, filter, metadata, processing status, and preview — wired to the knowledge service — arrive next."
	})] });
}
//#endregion
export { Documents as component };

import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { n as Workflow } from "../_libs/lucide-react.mjs";
import { t as EmptyState } from "./states-DyvfUIqi.mjs";
import { t as PageHeader } from "./PageHeader-B81R5vrl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/app.workflows-CrRjTFLh.js
var import_jsx_runtime = require_jsx_runtime();
function Workflows() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		title: "Workflows",
		description: "Every durable workflow across your organization."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
		icon: Workflow,
		title: "Workflow queue is being built",
		description: "Name, status, owner, started, waiting-for, and last-updated — wired to the workflow service — arrive next."
	})] });
}
//#endregion
export { Workflows as component };

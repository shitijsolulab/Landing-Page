import { n as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { O as ArrowRight, _ as Clock, a as Sparkles, i as Sun, u as Moon } from "../_libs/lucide-react.mjs";
import { n as api, t as ApiError } from "./api-BBLZWzDa.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { n as useTheme, t as ThemeProvider } from "./theme-CqIocJs7.mjs";
import { g as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as INTEGRATIONS, r as IntegrationLogo, t as CATEGORIES } from "./IntegrationLogo-DC2hzUur.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BaVynT_q.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var INDUSTRY_KEY = "aios.industry";
function setStoredIndustry(slug) {
	if (typeof window !== "undefined") window.localStorage.setItem(INDUSTRY_KEY, slug);
}
var INDUSTRIES = [
	{
		slug: "common",
		label: "All industries",
		blurb: "See the shared platform view",
		icon: "◎"
	},
	{
		slug: "accounting",
		label: "Accounting",
		blurb: "Invoices, ledger, close",
		icon: "₵"
	},
	{
		slug: "banking",
		label: "Banking",
		blurb: "Ops, KYC, servicing",
		icon: "🏦"
	},
	{
		slug: "construction",
		label: "Construction",
		blurb: "RFIs, drawings, schedules",
		icon: "⌂"
	},
	{
		slug: "hr",
		label: "HR & ATS",
		blurb: "Hiring, onboarding, payroll",
		icon: "❖"
	},
	{
		slug: "productivity",
		label: "Productivity",
		blurb: "Docs, tasks, calendars",
		icon: "✎"
	}
];
var INDUSTRY_CONTENT = {
	common: {
		heroTagline: "One AI operating system. Every line of business.",
		heroSub: "A shared core — identity, chat, workflow engine, document intelligence, connector hub — with copilots tuned to how your industry actually works.",
		workflow: {
			title: "A generic 45–60 min task, done in 5–10.",
			before: "Manual triage across email, files, and 3+ business systems.",
			after: "AI drafts, checks, and executes. A human reviews and approves.",
			steps: [
				{
					label: "Intake",
					detail: "Email, file, or chat message arrives."
				},
				{
					label: "Parse",
					detail: "Document intelligence extracts structured data."
				},
				{
					label: "Enrich",
					detail: "Connector hub pulls context from your business systems."
				},
				{
					label: "Draft",
					detail: "AI produces a response, record, or action."
				},
				{
					label: "Approve",
					detail: "Human reviews and clicks approve."
				},
				{
					label: "Execute",
					detail: "Action written back into your system of record."
				}
			]
		},
		connectors: {
			fallback: true,
			nango: [{
				name: "Email & Calendar",
				use: "Read, send, and schedule across your inbox."
			}, {
				name: "File Storage",
				use: "Access documents from your team drive."
			}],
			composio: [{
				name: "Line-of-Business System",
				use: "Bring your own — we scope the integration with you."
			}]
		}
	},
	accounting: {
		heroTagline: "AI that closes the books faster.",
		heroSub: "Invoice processing, vendor lookups, duplicate checks, and ledger updates — drafted by AI, approved by your controller.",
		workflow: {
			title: "Invoice Processing & Approval Copilot",
			before: "45+ minutes per invoice across email, drive, and ERP.",
			after: "5 minutes: review, approve, done.",
			steps: [
				{
					label: "Vendor emails invoice",
					detail: "Nango retrieves the message and attachment."
				},
				{
					label: "OCR extracts data",
					detail: "Line items, totals, and vendor info parsed."
				},
				{
					label: "Composio checks records",
					detail: "Vendor lookup + duplicate flag against QuickBooks/Xero."
				},
				{
					label: "AI drafts validation",
					detail: "Summary of matches, mismatches, and policy issues."
				},
				{
					label: "Human approves",
					detail: "Controller clicks approve in one screen."
				},
				{
					label: "Composio posts entry",
					detail: "Invoice created and confirmation emailed via Nango."
				}
			]
		},
		connectors: {
			nango: [
				{
					name: "Outlook",
					use: "Retrieve vendor invoices from shared inbox."
				},
				{
					name: "Gmail",
					use: "Retrieve vendor invoices and send confirmations."
				},
				{
					name: "Microsoft 365",
					use: "Auth and identity for the finance team."
				},
				{
					name: "Google Drive",
					use: "Access invoice PDFs and receipts."
				},
				{
					name: "Microsoft Teams",
					use: "Post approval requests to a finance channel."
				},
				{
					name: "Calendar",
					use: "Schedule close and approval deadlines."
				}
			],
			composio: [
				{
					name: "QuickBooks",
					use: "Create invoices, vendors, and journal entries."
				},
				{
					name: "Xero",
					use: "Ledger and journal retrieval, invoice posting."
				},
				{
					name: "CRM tools",
					use: "Cross-reference customers with A/R records."
				},
				{
					name: "ERP systems",
					use: "Sync invoices to your ERP of record."
				},
				{
					name: "Expense management",
					use: "Policy checks against submitted expenses."
				}
			]
		}
	},
	legal: {
		heroTagline: "AI that reads the contract before you do.",
		heroSub: "Matter intake, contract review, and playbook checks — drafted by AI, sent back over your existing systems.",
		workflow: {
			title: "Contract Review Copilot",
			before: "60+ minutes reading and comparing against the playbook.",
			after: "10 minutes: read the summary, adjust, send.",
			steps: [
				{
					label: "Contract arrives",
					detail: "Nango pulls the attachment from email."
				},
				{
					label: "OCR parses it",
					detail: "Clauses, parties, and dates extracted."
				},
				{
					label: "Composio pulls precedent",
					detail: "Prior matters and the firm's playbook loaded."
				},
				{
					label: "AI flags risk",
					detail: "Missing clauses, deviations, and red-flag terms."
				},
				{
					label: "Lawyer reviews",
					detail: "Summary + inline suggestions in one view."
				},
				{
					label: "Nango sends it back",
					detail: "Reviewed contract returned via Outlook or Gmail."
				}
			]
		},
		connectors: {
			nango: [
				{
					name: "Outlook",
					use: "Retrieve incoming contracts and correspondence."
				},
				{
					name: "Gmail",
					use: "Retrieve contracts and send replies."
				},
				{
					name: "Microsoft Teams",
					use: "Coordinate matter teams."
				},
				{
					name: "SharePoint",
					use: "Access matter document libraries."
				},
				{
					name: "Google Drive",
					use: "Access shared client folders."
				},
				{
					name: "OneDrive",
					use: "Access personal matter folders."
				},
				{
					name: "Google Calendar",
					use: "Schedule filings and depositions."
				}
			],
			composio: [
				{
					name: "Clio",
					use: "Matter management and time capture."
				},
				{
					name: "MyCase",
					use: "Client and matter records."
				},
				{
					name: "PracticePanther",
					use: "Matter and billing actions."
				},
				{
					name: "Ironclad",
					use: "Contract lifecycle actions."
				},
				{
					name: "DocuSign",
					use: "E-signature status and send."
				},
				{
					name: "Notion",
					use: "Playbook and knowledge base."
				},
				{
					name: "Jira",
					use: "Task tracking for matter workstreams."
				},
				{
					name: "Asana",
					use: "Matter task workflows."
				},
				{
					name: "Monday.com",
					use: "Matter pipelines and intake."
				}
			]
		}
	},
	construction: {
		heroTagline: "AI that answers the RFI before the site does.",
		heroSub: "RFI response, submittal tracking, and change-order drafting — grounded in your drawings, schedules, and PM system.",
		workflow: {
			title: "RFI Copilot",
			before: "A PM chasing drawings, schedules, and spec sections for hours.",
			after: "Draft response ready in minutes, PM approves and sends.",
			steps: [
				{
					label: "Contractor raises RFI",
					detail: "Nango retrieves the email or Teams message."
				},
				{
					label: "Docs parsed",
					detail: "OCR + document intelligence read attachments and drawings."
				},
				{
					label: "Composio pulls project data",
					detail: "Drawings, schedules, and specs from Procore/ACC."
				},
				{
					label: "AI drafts a response",
					detail: "Grounded in the project record, cites drawing refs."
				},
				{
					label: "PM approves",
					detail: "One-click approval with edits inline."
				},
				{
					label: "Nango sends reply",
					detail: "Response goes back over email or Teams."
				}
			]
		},
		connectors: {
			nango: [
				{
					name: "Outlook",
					use: "Retrieve RFIs and submittals from email."
				},
				{
					name: "Gmail",
					use: "Retrieve RFIs and send responses."
				},
				{
					name: "Microsoft Teams",
					use: "Read and post in project channels."
				},
				{
					name: "SharePoint",
					use: "Access project drawing sets."
				},
				{
					name: "Google Drive",
					use: "Access shared project folders."
				},
				{
					name: "OneDrive",
					use: "Access personal drawing folders."
				}
			],
			composio: [
				{
					name: "Procore",
					use: "RFIs, submittals, and change orders."
				},
				{
					name: "Autodesk Construction Cloud",
					use: "Drawings and model coordination."
				},
				{
					name: "Oracle Primavera P6",
					use: "Master schedule lookups."
				},
				{
					name: "Buildertrend",
					use: "Residential project actions."
				},
				{
					name: "Monday.com",
					use: "Project pipelines and punch lists."
				},
				{
					name: "Asana",
					use: "Task tracking across trades."
				},
				{
					name: "Jira",
					use: "Issue tracking for tech-heavy builds."
				},
				{
					name: "ClickUp",
					use: "Project management workspaces."
				},
				{
					name: "Smartsheet",
					use: "Schedules, budgets, and trackers."
				}
			]
		}
	}
};
function getContent(slug) {
	return INDUSTRY_CONTENT[slug] ?? INDUSTRY_CONTENT.common;
}
function Index() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThemeProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IndexContent, {}) });
}
function IndexContent() {
	const [industry, setIndustry] = (0, import_react.useState)("common");
	const [authOpen, setAuthOpen] = (0, import_react.useState)(false);
	const content = (0, import_react.useMemo)(() => getContent(industry), [industry]);
	const showFallbackNotice = industry !== "common" && !INDUSTRY_CONTENT[industry];
	const navigate = useNavigate();
	const { theme } = useTheme();
	const onAuthenticated = () => {
		setStoredIndustry(industry);
		navigate({ to: "/app" });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("landing-root min-h-screen bg-background text-foreground", theme === "dark" && "dark"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Nav, { onLogin: () => setAuthOpen(true) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, {
				content,
				industry,
				setIndustry,
				showFallbackNotice
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IntegrationCatalog, { industry }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CoreDiagram, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorkflowSection, { content }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlatformGrid, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CTASection, { onLogin: () => setAuthOpen(true) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {}),
			authOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthModal, {
				onClose: () => setAuthOpen(false),
				onAuthenticated
			})
		]
	});
}
function Nav({ onLogin }) {
	const { theme, toggle } = useTheme();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
		className: "sticky top-0 z-30 border-b border-border bg-background/80 backdrop-blur",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-7xl items-center justify-between px-5 py-3.5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: "#",
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid h-8 w-8 place-items-center rounded-lg bg-primary text-sm font-bold text-primary-foreground",
						children: "AI"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[15px] font-semibold tracking-tight",
						children: "Industry AI OS"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					className: "hidden items-center gap-8 text-sm font-medium text-muted-foreground md:flex",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#integrations",
							className: "transition hover:text-foreground",
							children: "Integrations"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#platform",
							className: "transition hover:text-foreground",
							children: "Platform"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#workflow",
							className: "transition hover:text-foreground",
							children: "Workflow"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "hidden items-center gap-1.5 rounded-lg border border-border px-2.5 py-1.5 text-xs font-medium text-muted-foreground sm:inline-flex",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
								viewBox: "0 0 16 16",
								className: "h-3.5 w-3.5 fill-current",
								"aria-hidden": true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M8 0a8 8 0 0 0-2.53 15.59c.4.07.55-.17.55-.38v-1.34c-2.22.48-2.69-1.07-2.69-1.07-.36-.92-.89-1.17-.89-1.17-.73-.5.05-.49.05-.49.8.06 1.23.83 1.23.83.71 1.23 1.87.87 2.33.67.07-.52.28-.87.5-1.07-1.77-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.83-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.22 2.2.82a7.6 7.6 0 0 1 4 0c1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.52.56.83 1.28.83 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48v2.19c0 .21.15.46.55.38A8 8 0 0 0 8 0Z" })
							}), "10.9k"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: toggle,
							"aria-label": theme === "dark" ? "Switch to light mode" : "Switch to dark mode",
							className: "rounded-lg p-2 text-muted-foreground transition hover:bg-secondary hover:text-foreground",
							children: theme === "dark" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "h-4 w-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "h-4 w-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: onLogin,
							className: "rounded-lg px-3.5 py-1.5 text-sm font-medium text-foreground transition hover:bg-secondary",
							children: "Log in"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: onLogin,
							className: "rounded-lg bg-foreground px-4 py-1.5 text-sm font-semibold text-background transition hover:opacity-90",
							children: "Sign up"
						})
					]
				})
			]
		})
	});
}
function Hero({ content, industry, setIndustry, showFallbackNotice }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative border-b border-border/60",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pointer-events-none absolute inset-0 overflow-hidden",
			"aria-hidden": true,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 grid-bg opacity-60" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -top-40 left-1/2 h-96 w-[52rem] -translate-x-1/2 rounded-full bg-primary/10 blur-3xl" })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mx-auto max-w-7xl px-5 py-20 md:py-28",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-6 inline-flex items-center gap-2 rounded-full border border-border bg-surface px-3 py-1 text-xs font-medium text-muted-foreground shadow-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-1.5 w-1.5 rounded-full bg-primary" }),
						INTEGRATIONS.length,
						"+ supported integrations"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "max-w-3xl text-4xl font-semibold leading-[1.05] tracking-tight md:text-6xl",
					children: content.heroTagline
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-5 max-w-2xl text-base text-muted-foreground md:text-lg",
					children: content.heroSub
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 flex flex-col gap-3 sm:flex-row sm:items-stretch",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IndustryPicker, {
							value: industry,
							onChange: setIndustry
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#workflow",
							className: "inline-flex items-center justify-center rounded-xl bg-foreground px-6 py-3 text-sm font-semibold uppercase tracking-wide text-background transition hover:opacity-90",
							children: "Start building"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#integrations",
							className: "inline-flex items-center justify-center rounded-xl border border-border bg-surface px-6 py-3 text-sm font-semibold uppercase tracking-wide text-foreground transition hover:border-primary hover:text-primary",
							children: "View integrations"
						})
					]
				}),
				showFallbackNotice && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6 max-w-2xl rounded-lg border border-border bg-surface/70 px-4 py-3 text-sm text-muted-foreground",
					children: "Deep content for this industry is in active scoping — you're seeing the shared platform view. Talk to us about your stack."
				})
			]
		})]
	});
}
function IndustryPicker({ value, onChange }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [activeIdx, setActiveIdx] = (0, import_react.useState)(0);
	const ref = (0, import_react.useRef)(null);
	const current = INDUSTRIES.find((i) => i.slug === value) ?? INDUSTRIES[0];
	(0, import_react.useEffect)(() => {
		if (!open) return;
		setActiveIdx(Math.max(0, INDUSTRIES.findIndex((i) => i.slug === value)));
		const onDoc = (e) => {
			if (!ref.current?.contains(e.target)) setOpen(false);
		};
		document.addEventListener("mousedown", onDoc);
		return () => document.removeEventListener("mousedown", onDoc);
	}, [open, value]);
	const onKey = (e) => {
		if (!open && (e.key === "Enter" || e.key === " " || e.key === "ArrowDown")) {
			e.preventDefault();
			setOpen(true);
			return;
		}
		if (!open) return;
		if (e.key === "Escape") setOpen(false);
		if (e.key === "ArrowDown") {
			e.preventDefault();
			setActiveIdx((i) => (i + 1) % INDUSTRIES.length);
		}
		if (e.key === "ArrowUp") {
			e.preventDefault();
			setActiveIdx((i) => (i - 1 + INDUSTRIES.length) % INDUSTRIES.length);
		}
		if (e.key === "Enter") {
			e.preventDefault();
			onChange(INDUSTRIES[activeIdx].slug);
			setOpen(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref,
		className: "relative w-full sm:w-[360px]",
		onKeyDown: onKey,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			"aria-haspopup": "listbox",
			"aria-expanded": open,
			onClick: () => setOpen((o) => !o),
			className: "group flex w-full items-center gap-3 rounded-xl border border-border bg-surface p-2.5 pr-3 text-left transition hover:border-primary/60 focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid h-11 w-11 shrink-0 place-items-center rounded-lg bg-primary/15 text-lg text-primary",
					children: current.icon
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block font-mono text-[10px] uppercase tracking-wider text-muted-foreground",
						children: "Tailor this page to"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block truncate text-sm font-semibold text-foreground",
						children: current.slug === "common" ? "Choose your industry" : current.label
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
					className: `h-4 w-4 shrink-0 text-muted-foreground transition ${open ? "rotate-180" : ""}`,
					viewBox: "0 0 20 20",
					fill: "none",
					stroke: "currentColor",
					strokeWidth: "2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M5 8l5 5 5-5",
						strokeLinecap: "round",
						strokeLinejoin: "round"
					})
				})
			]
		}), open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			role: "listbox",
			className: "absolute left-0 right-0 z-40 mt-2 max-h-[420px] overflow-auto rounded-xl border border-border bg-surface p-1.5 shadow-2xl",
			children: INDUSTRIES.map((i, idx) => {
				const selected = i.slug === value;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					role: "option",
					"aria-selected": selected,
					onMouseEnter: () => setActiveIdx(idx),
					onClick: () => {
						onChange(i.slug);
						setOpen(false);
					},
					className: `flex w-full items-center gap-3 rounded-lg px-2.5 py-2 text-left transition ${idx === activeIdx ? "bg-surface-2" : ""}`,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `grid h-9 w-9 shrink-0 place-items-center rounded-md text-base ${selected ? "bg-primary text-primary-foreground" : "bg-background text-primary"}`,
							children: i.icon
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block truncate text-sm font-medium text-foreground",
								children: i.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block truncate text-xs text-muted-foreground",
								children: i.blurb
							})]
						}),
						selected && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-[10px] uppercase tracking-wider text-primary",
							children: "Active"
						})
					]
				}, i.slug);
			})
		})]
	});
}
function CoreDiagram() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "platform",
		className: "border-b border-border/60 py-20",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-12 flex flex-col gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-mono text-xs uppercase tracking-wider text-primary",
					children: "The shared core"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "max-w-2xl text-3xl font-semibold tracking-tight md:text-4xl",
					children: "Every copilot runs on the same operating system."
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto grid max-w-4xl grid-cols-2 gap-4 md:grid-cols-3",
				children: [
					"Identity",
					"AI Chat",
					"Workflow Engine",
					"Document Intelligence",
					"Connector Hub",
					"Admin"
				].map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border border-border bg-surface p-5 transition hover:border-primary/60",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 font-mono text-xs text-muted-foreground",
						children: ["0", i + 1]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-base font-medium",
						children: s
					})]
				}, s))
			})]
		})
	});
}
function WorkflowSection({ content }) {
	const { workflow } = content;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "workflow",
		className: "border-b border-border/60 bg-surface-2 py-20",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-5xl px-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-12 flex flex-col items-center gap-3 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-xs uppercase tracking-wider text-primary",
							children: "Workflow example"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "max-w-2xl text-3xl font-semibold tracking-tight md:text-4xl",
							children: workflow.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "max-w-xl text-sm text-muted-foreground",
							children: "The same six steps every time — AI does the work, a human stays in control."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-14 grid items-stretch gap-4 md:grid-cols-[1fr_auto_1fr]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl border border-border bg-background p-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-3 flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-4 w-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs font-semibold uppercase tracking-wider text-muted-foreground",
									children: "Before"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-foreground/80",
								children: workflow.before
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex items-center justify-center py-2 md:py-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid h-10 w-10 place-items-center rounded-full border border-border bg-background text-muted-foreground",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-5 w-5" })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl border border-primary/30 bg-primary/5 p-6 ring-1 ring-primary/10",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-3 flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-4 w-4 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs font-semibold uppercase tracking-wider text-primary",
									children: "After"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-foreground/90",
								children: workflow.after
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "relative mx-auto max-w-2xl",
					children: workflow.steps.map((s, i) => {
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "relative flex gap-5 pb-8 last:pb-0",
							children: [
								!(i === workflow.steps.length - 1) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "absolute left-[19px] top-10 h-[calc(100%-1.5rem)] w-px bg-border",
									"aria-hidden": true
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "z-10 grid h-10 w-10 shrink-0 place-items-center rounded-full border border-primary/30 bg-background text-sm font-semibold text-primary",
									children: i + 1
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "pt-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[15px] font-semibold text-foreground",
										children: s.label
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-sm text-muted-foreground",
										children: s.detail
									})]
								})
							]
						}, s.label);
					})
				})
			]
		})
	});
}
var INDUSTRY_TO_CATEGORY = {
	common: "all",
	accounting: "Accounting",
	banking: "Banking",
	construction: "Construction",
	hr: "HR & ATS",
	productivity: "Productivity"
};
function IntegrationCatalog({ industry }) {
	const [active, setActive] = (0, import_react.useState)(INDUSTRY_TO_CATEGORY[industry] ?? "all");
	(0, import_react.useEffect)(() => {
		setActive(INDUSTRY_TO_CATEGORY[industry] ?? "all");
	}, [industry]);
	const items = (0, import_react.useMemo)(() => active === "all" ? INTEGRATIONS : INTEGRATIONS.filter((i) => i.category === active), [active]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "integrations",
		className: "border-b border-border/60 py-20",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-8 flex flex-col gap-2 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-xs uppercase tracking-wider text-primary",
							children: "Integrations"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "mx-auto max-w-2xl text-3xl font-semibold tracking-tight md:text-4xl",
							children: [INTEGRATIONS.length, "+ APIs your copilots can talk to."]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mx-auto max-w-2xl text-sm text-muted-foreground",
							children: "Authenticate once, then read and act across the tools your team already uses — from email and storage to CRM, accounting, and ticketing."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-8 flex flex-wrap justify-center gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CatalogChip, {
						label: "All",
						active: active === "all",
						onClick: () => setActive("all")
					}), CATEGORIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CatalogChip, {
						label: c,
						active: active === c,
						onClick: () => setActive(c)
					}, c))]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6",
					children: items.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col items-center gap-3 rounded-xl border border-border bg-surface p-5 text-center transition hover:border-primary/50 hover:shadow-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IntegrationLogo, {
							name: i.name,
							domain: i.domain,
							className: "h-12 w-12"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "truncate text-sm font-medium",
								children: i.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[11px] text-muted-foreground",
								children: i.category
							})]
						})]
					}, i.slug))
				})
			]
		})
	});
}
function CatalogChip({ label, active, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		onClick,
		className: `rounded-full border px-3 py-1 text-xs font-medium transition ${active ? "border-primary bg-primary text-primary-foreground" : "border-border bg-surface text-muted-foreground hover:border-primary/40 hover:text-foreground"}`,
		children: label
	});
}
function PlatformGrid() {
	const rows = [
		{
			k: "Identity",
			v: "SSO, RBAC, audit trails."
		},
		{
			k: "AI Chat",
			v: "Grounded chat across your data."
		},
		{
			k: "Workflow Engine",
			v: "Approvals, escalations, retries."
		},
		{
			k: "Document Intelligence",
			v: "OCR + structured extraction."
		},
		{
			k: "Connector Hub",
			v: "Nango + Composio, one config."
		},
		{
			k: "Admin",
			v: "Usage, cost, and safety controls."
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "border-b border-border/60 py-20",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-mono text-xs uppercase tracking-wider text-primary",
					children: "Under the hood"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-2 max-w-2xl text-3xl font-semibold tracking-tight md:text-4xl",
					children: "Every copilot inherits this."
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-hidden rounded-2xl border border-border",
				children: rows.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `grid grid-cols-1 gap-2 px-5 py-4 md:grid-cols-[220px_1fr] ${i !== rows.length - 1 ? "border-b border-border" : ""} bg-surface`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-mono text-xs uppercase tracking-wider text-muted-foreground",
						children: r.k
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-sm text-foreground/90",
						children: r.v
					})]
				}, r.k))
			})]
		})
	});
}
function CTASection({ onLogin }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "py-20",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-4xl px-5 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-3xl font-semibold tracking-tight md:text-4xl",
					children: "Bring the AI OS to your industry."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mx-auto mt-3 max-w-xl text-sm text-muted-foreground",
					children: "Sign in to explore your workspace, or create an account to scope integrations for your stack."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: onLogin,
					className: "mt-6 inline-flex items-center justify-center rounded-lg bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground transition hover:opacity-90",
					children: "Get started"
				})
			]
		})
	});
}
function Footer() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
		className: "border-t border-border bg-surface-2",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-5 py-14",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-10 md:grid-cols-[1.5fr_repeat(3,1fr)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid h-8 w-8 place-items-center rounded-lg bg-primary text-sm font-bold text-primary-foreground",
						children: "AI"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[15px] font-semibold tracking-tight",
						children: "Industry AI OS"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-xs text-sm text-muted-foreground",
					children: "One AI operating system for every line of business — with the integrations your team already relies on."
				})] }), [
					{
						title: "Product",
						links: [
							"Integrations",
							"Platform",
							"Workflows",
							"Pricing"
						]
					},
					{
						title: "Resources",
						links: [
							"Docs",
							"API reference",
							"Changelog",
							"Status"
						]
					},
					{
						title: "Company",
						links: [
							"About",
							"Customers",
							"Careers",
							"Contact"
						]
					}
				].map((col) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mb-3 text-xs font-semibold uppercase tracking-wider text-foreground",
					children: col.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-2.5 text-sm text-muted-foreground",
					children: col.links.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "#",
						className: "transition hover:text-foreground",
						children: l
					}) }, l))
				})] }, col.title))]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-12 flex flex-col items-center justify-between gap-3 border-t border-border pt-6 text-xs text-muted-foreground md:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					"© ",
					(/* @__PURE__ */ new Date()).getFullYear(),
					" Industry AI OS. All rights reserved."
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-mono",
					children: "Built on a shared AI core"
				})]
			})]
		})
	});
}
function AuthModal({ onClose, onAuthenticated }) {
	const [tab, setTab] = (0, import_react.useState)("login");
	const [status, setStatus] = (0, import_react.useState)(null);
	const dialogRef = (0, import_react.useRef)(null);
	const firstFieldRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const onKey = (e) => {
			if (e.key === "Escape") onClose();
			if (e.key === "Tab" && dialogRef.current) {
				const focusables = dialogRef.current.querySelectorAll("button, [href], input, select, textarea, [tabindex]:not([tabindex=\"-1\"])");
				if (focusables.length === 0) return;
				const first = focusables[0];
				const last = focusables[focusables.length - 1];
				if (e.shiftKey && document.activeElement === first) {
					e.preventDefault();
					last.focus();
				} else if (!e.shiftKey && document.activeElement === last) {
					e.preventDefault();
					first.focus();
				}
			}
		};
		document.addEventListener("keydown", onKey);
		firstFieldRef.current?.focus();
		document.body.style.overflow = "hidden";
		return () => {
			document.removeEventListener("keydown", onKey);
			document.body.style.overflow = "";
		};
	}, [onClose]);
	(0, import_react.useEffect)(() => {
		firstFieldRef.current?.focus();
		setStatus(null);
	}, [tab]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center bg-black/60 px-4",
		onClick: onClose,
		role: "dialog",
		"aria-modal": "true",
		"aria-labelledby": "auth-title",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			ref: dialogRef,
			onClick: (e) => e.stopPropagation(),
			className: "w-full max-w-md rounded-2xl border border-border bg-surface p-6 shadow-2xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-5 flex items-start justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						id: "auth-title",
						className: "text-lg font-semibold",
						children: tab === "login" ? "Welcome back" : "Create your account"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted-foreground",
						children: tab === "login" ? "Sign in to your workspace." : "Get access to your industry copilot."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: onClose,
						"aria-label": "Close",
						className: "rounded-md p-1 text-muted-foreground hover:bg-surface-2 hover:text-foreground",
						children: "✕"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-5 grid grid-cols-2 gap-1 rounded-lg bg-background p-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setTab("login"),
						className: `rounded-md px-3 py-1.5 text-sm font-medium transition ${tab === "login" ? "bg-surface text-foreground" : "text-muted-foreground"}`,
						children: "Log in"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setTab("signup"),
						className: `rounded-md px-3 py-1.5 text-sm font-medium transition ${tab === "signup" ? "bg-surface text-foreground" : "text-muted-foreground"}`,
						children: "Sign up"
					})]
				}),
				status ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg border border-primary/40 bg-primary/5 p-4 text-sm",
					children: [status, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: onClose,
							className: "w-full rounded-md bg-primary py-2 text-sm font-semibold text-primary-foreground hover:opacity-90",
							children: "Close"
						})
					})]
				}) : tab === "login" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoginForm, {
					firstFieldRef,
					onAuthenticated
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignupForm, {
					firstFieldRef,
					onSuccess: (m) => setStatus(m)
				})
			]
		})
	});
}
function Field({ label, error, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-1.5 text-xs font-medium text-muted-foreground",
				children: label
			}),
			children,
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-1 text-xs text-destructive",
				children: error
			})
		]
	});
}
var inputCls = "w-full rounded-md border border-border bg-background px-3 py-2 text-sm outline-none transition focus:border-primary focus:ring-1 focus:ring-primary";
function isEmail(v) {
	return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
}
async function handleSignup(_) {
	await new Promise((r) => setTimeout(r, 400));
	return { ok: true };
}
function LoginForm({ firstFieldRef, onAuthenticated }) {
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [errors, setErrors] = (0, import_react.useState)({});
	const [loading, setLoading] = (0, import_react.useState)(false);
	const submit = async (e) => {
		e.preventDefault();
		const errs = {};
		if (!email) errs.email = "Email is required";
		else if (!isEmail(email)) errs.email = "Enter a valid email";
		if (!password) errs.password = "Password is required";
		setErrors(errs);
		if (Object.keys(errs).length) return;
		setLoading(true);
		try {
			await api.login(email, password);
			onAuthenticated();
		} catch (err) {
			let msg = "Could not reach the platform. Is the backend running?";
			if (err instanceof ApiError) msg = err.status === 401 ? "Invalid email or password." : err.message;
			setErrors({ form: msg });
		} finally {
			setLoading(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: submit,
		className: "space-y-3",
		noValidate: true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Work email",
				error: errors.email,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					ref: firstFieldRef,
					type: "email",
					value: email,
					onChange: (e) => setEmail(e.target.value),
					className: inputCls,
					placeholder: "you@company.com",
					autoComplete: "email"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Password",
				error: errors.password,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "password",
					value: password,
					onChange: (e) => setPassword(e.target.value),
					className: inputCls,
					placeholder: "••••••••",
					autoComplete: "current-password"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex items-center justify-between",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "text-xs text-muted-foreground hover:text-foreground",
					children: "Forgot password?"
				})
			}),
			errors.form && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-xs text-destructive",
				children: errors.form
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "submit",
				disabled: loading,
				className: "mt-2 w-full rounded-md bg-primary py-2 text-sm font-semibold text-primary-foreground transition hover:opacity-90 disabled:opacity-60",
				children: loading ? "Signing in…" : "Log in"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative my-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute inset-0 flex items-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-px w-full bg-border" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "relative text-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "bg-surface px-2 text-[11px] uppercase tracking-wider text-muted-foreground",
						children: "or"
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setErrors({ form: "SSO isn't wired yet — sign in with email + password." }),
				className: "w-full rounded-md border border-border bg-background py-2 text-sm font-medium hover:border-primary",
				children: "Continue with SSO"
			})
		]
	});
}
function SignupForm({ firstFieldRef, onSuccess }) {
	const [name, setName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [company, setCompany] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [errors, setErrors] = (0, import_react.useState)({});
	const [loading, setLoading] = (0, import_react.useState)(false);
	const submit = async (e) => {
		e.preventDefault();
		const errs = {};
		if (!name.trim()) errs.name = "Name is required";
		if (!email) errs.email = "Email is required";
		else if (!isEmail(email)) errs.email = "Enter a valid work email";
		if (!company.trim()) errs.company = "Company is required";
		if (!password || password.length < 8) errs.password = "Password must be at least 8 characters";
		setErrors(errs);
		if (Object.keys(errs).length) return;
		setLoading(true);
		await handleSignup({
			name,
			email,
			company,
			password
		});
		setLoading(false);
		onSuccess(`Check your email — we sent a confirmation link to ${email}.`);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: submit,
		className: "space-y-3",
		noValidate: true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Full name",
				error: errors.name,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					ref: firstFieldRef,
					value: name,
					onChange: (e) => setName(e.target.value),
					className: inputCls,
					placeholder: "Ada Lovelace"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Work email",
				error: errors.email,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "email",
					value: email,
					onChange: (e) => setEmail(e.target.value),
					className: inputCls,
					placeholder: "you@company.com",
					autoComplete: "email"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Company",
				error: errors.company,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: company,
					onChange: (e) => setCompany(e.target.value),
					className: inputCls,
					placeholder: "Acme LLP"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Password",
				error: errors.password,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "password",
					value: password,
					onChange: (e) => setPassword(e.target.value),
					className: inputCls,
					placeholder: "At least 8 characters",
					autoComplete: "new-password"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "submit",
				disabled: loading,
				className: "mt-2 w-full rounded-md bg-primary py-2 text-sm font-semibold text-primary-foreground transition hover:opacity-90 disabled:opacity-60",
				children: loading ? "Creating account…" : "Create account"
			})
		]
	});
}
//#endregion
export { Index as component };

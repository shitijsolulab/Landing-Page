//#region node_modules/.nitro/vite/services/ssr/assets/api-BBLZWzDa.js
var API_URL = "http://localhost:8000".replace(/\/$/, "") ?? "http://localhost:8000";
var TOKEN_KEY = "aios.access_token";
function getToken() {
	if (typeof window === "undefined") return null;
	return window.localStorage.getItem(TOKEN_KEY);
}
function setToken(token) {
	if (typeof window !== "undefined") window.localStorage.setItem(TOKEN_KEY, token);
}
function logout() {
	if (typeof window !== "undefined") window.localStorage.removeItem(TOKEN_KEY);
}
var ApiError = class extends Error {
	status;
	constructor(message, status) {
		super(message);
		this.status = status;
		this.name = "ApiError";
	}
};
async function request(path, init = {}) {
	const token = getToken();
	const resp = await fetch(`${API_URL}${path}`, {
		...init,
		headers: {
			"Content-Type": "application/json",
			...token ? { Authorization: `Bearer ${token}` } : {},
			...init.headers ?? {}
		}
	});
	if (!resp.ok) {
		let detail = resp.statusText;
		try {
			const body = await resp.json();
			detail = body.message ?? body.error ?? detail;
		} catch {}
		throw new ApiError(detail, resp.status);
	}
	return resp.status === 204 ? void 0 : await resp.json();
}
async function login(email, password) {
	setToken((await request("/auth/token", {
		method: "POST",
		body: JSON.stringify({
			username: email,
			password
		})
	})).access_token);
	return getMe();
}
function getMe() {
	return request("/api/identity/me");
}
function chat(input) {
	return request("/api/orchestrator/chat", {
		method: "POST",
		body: JSON.stringify(input)
	});
}
/** Streaming chat via SSE. Yields text deltas; caller concatenates. */
async function* chatStream(input) {
	const resp = await fetch(`${API_URL}/api/orchestrator/chat/stream`, {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			...getToken() ? { Authorization: `Bearer ${getToken()}` } : {}
		},
		body: JSON.stringify(input)
	});
	if (!resp.ok || !resp.body) throw new ApiError("Stream failed", resp.status);
	const reader = resp.body.getReader();
	const decoder = new TextDecoder();
	let buffer = "";
	for (;;) {
		const { value, done } = await reader.read();
		if (done) break;
		buffer += decoder.decode(value, { stream: true });
		const lines = buffer.split("\n\n");
		buffer = lines.pop() ?? "";
		for (const line of lines) {
			const data = line.replace(/^data: /, "").trim();
			if (!data || data === "[DONE]") continue;
			try {
				yield JSON.parse(data);
			} catch {}
		}
	}
}
function listDocuments() {
	return request("/api/knowledge/documents");
}
function getDocument(id) {
	return request(`/api/knowledge/documents/${id}`);
}
async function uploadDocument(file) {
	const form = new FormData();
	form.append("file", file);
	const resp = await fetch(`${API_URL}/api/knowledge/documents`, {
		method: "POST",
		headers: { ...getToken() ? { Authorization: `Bearer ${getToken()}` } : {} },
		body: form
	});
	if (!resp.ok) throw new ApiError("Upload failed", resp.status);
	return resp.json();
}
function retrieve(query, topK = 5) {
	return request("/api/knowledge/retrieve", {
		method: "POST",
		body: JSON.stringify({
			query,
			top_k: topK
		})
	});
}
function listWorkflows() {
	return request("/api/workflows/workflows");
}
function getWorkflow(id) {
	return request(`/api/workflows/workflows/${id}`);
}
function startDocumentReview(documentId) {
	return request("/api/workflows/workflows/document-review", {
		method: "POST",
		body: JSON.stringify({ document_id: documentId })
	});
}
function approveWorkflow(id, comment = "") {
	return request(`/api/workflows/workflows/${id}/approve`, {
		method: "POST",
		body: JSON.stringify({ comment })
	});
}
function rejectWorkflow(id, comment = "") {
	return request(`/api/workflows/workflows/${id}/reject`, {
		method: "POST",
		body: JSON.stringify({ comment })
	});
}
function listConnectors() {
	return request("/api/connectors/connectors");
}
function configureConnector(key, body) {
	return request(`/api/connectors/connectors/${key}`, {
		method: "PUT",
		body: JSON.stringify(body)
	});
}
function listAuditEvents(params) {
	return request(`/api/audit/events${params?.limit ? `?limit=${params.limit}` : ""}`);
}
function getTenant() {
	return request("/api/admin/tenant");
}
function updateTenantSettings(settings) {
	return request("/api/admin/tenant/settings", {
		method: "PUT",
		body: JSON.stringify({ settings })
	});
}
function systemHealth() {
	return request("/api/admin/system/health");
}
function listUsers() {
	return request("/api/identity/users");
}
function assignRole(userId, role) {
	return request(`/api/identity/users/${userId}/roles`, {
		method: "POST",
		body: JSON.stringify({ role })
	});
}
var api = {
	apiUrl: API_URL,
	getToken,
	logout,
	login,
	getMe,
	chat,
	chatStream,
	listDocuments,
	getDocument,
	uploadDocument,
	retrieve,
	listWorkflows,
	getWorkflow,
	startDocumentReview,
	approveWorkflow,
	rejectWorkflow,
	listConnectors,
	configureConnector,
	listAuditEvents,
	getTenant,
	updateTenantSettings,
	systemHealth,
	listUsers,
	assignRole
};
//#endregion
export { api as n, ApiError as t };

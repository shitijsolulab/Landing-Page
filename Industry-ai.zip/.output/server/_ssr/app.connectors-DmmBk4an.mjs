import { n as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { c as Search, l as Plus, x as Check } from "../_libs/lucide-react.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { t as PageHeader } from "./PageHeader-B81R5vrl.mjs";
import { n as INTEGRATIONS, r as IntegrationLogo, t as CATEGORIES } from "./IntegrationLogo-DC2hzUur.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/app.connectors-DmmBk4an.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Connectors() {
	const [query, setQuery] = (0, import_react.useState)("");
	const [active, setActive] = (0, import_react.useState)("all");
	const results = (0, import_react.useMemo)(() => {
		const q = query.trim().toLowerCase();
		return INTEGRATIONS.filter((i) => {
			const matchesCat = active === "all" || i.category === active;
			const matchesQuery = !q || i.name.toLowerCase().includes(q) || i.category.toLowerCase().includes(q);
			return matchesCat && matchesQuery;
		});
	}, [query, active]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Connector Hub",
			description: `${INTEGRATIONS.length}+ supported integrations. Authenticate once, then let your copilots read and act across them.`
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-5 flex flex-col gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative max-w-md",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: query,
					onChange: (e) => setQuery(e.target.value),
					placeholder: "Search integrations…",
					className: "w-full rounded-lg border border-border bg-surface py-2 pl-9 pr-3 text-sm outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/20"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
					label: "All",
					active: active === "all",
					onClick: () => setActive("all")
				}), CATEGORIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
					label: c,
					active: active === c,
					onClick: () => setActive(c)
				}, c))]
			})]
		}),
		results.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-xl border border-dashed border-border py-16 text-center text-sm text-muted-foreground",
			children: [
				"No integrations match “",
				query,
				"”."
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5",
			children: results.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IntegrationCard, { integration: i }, i.slug))
		})
	] });
}
function Chip({ label, active, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		onClick,
		className: cn("rounded-full border px-3 py-1 text-xs font-medium transition", active ? "border-primary bg-primary text-primary-foreground" : "border-border bg-surface text-muted-foreground hover:border-primary/40 hover:text-foreground"),
		children: label
	});
}
function IntegrationCard({ integration }) {
	const [requested, setRequested] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "group relative flex flex-col gap-3 rounded-xl border border-border bg-surface p-4 transition hover:border-primary/50 hover:shadow-sm",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IntegrationLogo, {
					name: integration.name,
					domain: integration.domain,
					className: "h-11 w-11"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "rounded-full bg-secondary px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide text-muted-foreground",
					children: integration.auth ? "Auth" : "Action"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "truncate text-sm font-semibold text-foreground",
					children: integration.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs text-muted-foreground",
					children: integration.category
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: () => setRequested((r) => !r),
				className: cn("mt-1 inline-flex items-center justify-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-medium transition", requested ? "border-primary/40 bg-primary/10 text-primary" : "border-border bg-background text-foreground hover:border-primary hover:text-primary"),
				children: requested ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-3.5 w-3.5" }), " Requested"] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-3.5 w-3.5" }), " Connect"] })
			})
		]
	});
}
//#endregion
export { Connectors as component };

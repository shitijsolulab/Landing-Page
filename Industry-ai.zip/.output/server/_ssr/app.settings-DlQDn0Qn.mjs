import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { s as Settings } from "../_libs/lucide-react.mjs";
import { t as EmptyState } from "./states-DyvfUIqi.mjs";
import { t as PageHeader } from "./PageHeader-B81R5vrl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/app.settings-DlQDn0Qn.js
var import_jsx_runtime = require_jsx_runtime();
function SettingsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		title: "Settings",
		description: "Tenant, profile, security, and provider configuration."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
		icon: Settings,
		title: "Settings is being built",
		description: "Tenant settings, profile, security, notifications, and LLM providers — wired to identity + admin services — arrive next. (API keys and LLM-provider config need new backend endpoints.)"
	})] });
}
//#endregion
export { SettingsPage as component };

import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { S as ChartColumn } from "../_libs/lucide-react.mjs";
import { t as EmptyState } from "./states-DyvfUIqi.mjs";
import { t as PageHeader } from "./PageHeader-B81R5vrl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/app.analytics-Qd6SZtaX.js
var import_jsx_runtime = require_jsx_runtime();
function Analytics() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		title: "Analytics",
		description: "Usage across AI, workflows, approvals, and connectors."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
		icon: ChartColumn,
		title: "Analytics is being built",
		description: "Generic metrics (AI requests, workflow executions, approval times, documents processed, connector usage) derived from existing data — arrive next. No dedicated metrics API exists yet, so these will be computed from the real list endpoints."
	})] });
}
//#endregion
export { Analytics as component };
